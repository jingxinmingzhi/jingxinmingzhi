#!/usr/bin/python
# -*- coding: UTF-8 -*-

# coding=utf-8
import chardet

a = "\x74\x73"
#fencoding = chardet.detect(a)  #这行可以判断当前字符串的格式，以便后面设置打印字符的字符编码
#print(fencoding)
#a = a.decode('UTF-8')
print(a)
